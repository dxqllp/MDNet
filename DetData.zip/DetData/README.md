数据集下载地址   
ClinicDB  
官方链接 ：  https://polyp.grand-challenge.org/CVCClinicDB/  
引用：  
@article{bernal2015wm, title={WM-DOVA maps for accurate polyp highlighting in colonoscopy: Validation vs. saliency maps from physicians}, author={Bernal, Jorge and S{'a}nchez, F Javier and Fern{'a}ndez-Esparrach, Gloria and Gil, Debora and Rodr{'\i}guez, Cristina and Vilari{~n}o, Fernando}, journal={Computerized medical imaging and graphics}, volume={43}, pages={99--111}, year={2015}, publisher={Elsevier} }

Kavsir  
官方链接 ：  https://datasets.simula.no/downloads/kvasir-seg.zip  
引用：  
@inproceedings{jha2020kvasir,
  title={Kvasir-seg: A segmented polyp dataset},
  author={Jha, Debesh and Smedsrud, Pia H and Riegler, Michael A and Halvorsen, P{\aa}l and de Lange, Thomas and Johansen, Dag and Johansen, H{\aa}vard D},
  booktitle={MultiMedia Modeling: 26th International Conference, MMM 2020, Daejeon, South Korea, January 5--8, 2020, Proceedings, Part II 26},
  pages={451--462},
  year={2020},
  organization={Springer}
}
